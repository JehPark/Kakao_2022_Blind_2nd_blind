package com.company.api.domain;

public class AuthKey {
    private String auth_key;
    private int problem;
    private int time;

    public String getAuth_key() {
        return auth_key;
    }

    public int getProblem() {
        return problem;
    }

    public int getTime() {
        return time;
    }
}

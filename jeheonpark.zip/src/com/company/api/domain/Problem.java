package com.company.api.domain;

public class Problem {
    private int problem;

    public Problem(int problem) {
        this.problem = problem;
    }
}

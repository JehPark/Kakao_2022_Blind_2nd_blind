package com.company.domain;

public class MatchResult {
    public double total;
    public double win;

    public MatchResult(double total, double win) {
        this.total = total;
        this.win = win;
    }
}

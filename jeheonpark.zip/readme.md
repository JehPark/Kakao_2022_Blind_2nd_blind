## Library:  
1. GSON: 2.8.8 version License: https://www.apache.org/licenses/LICENSE-2.0.txt
2. JSON in Java: 20210307 version License: http://json.org/license.html